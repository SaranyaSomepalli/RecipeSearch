import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  search_string:String=""

  constructor(private http:HttpClient) { }

  getData():Observable<Array<object>>
  {
    return this.http.get<Array<Object>>(`https://api.edamam.com/search?q=${this.search_string}&app_id=80518a75&app_key=3d4036f4e7b372cc7aa2d47cb24c3255	`)
  }
}

//https://api.edamam.com/search?q=chicken&app_id=${YOUR_APP_ID}&app_key=${YOUR_APP_KEY}&from=0&to=3&calories=591-722&health=alcohol-free"