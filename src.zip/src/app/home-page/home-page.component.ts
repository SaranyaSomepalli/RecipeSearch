import { Component, OnInit } from '@angular/core';
import {DataService} from "../data.service";
import {ActivatedRoute} from "@angular/router";
import {RecipesComponent} from '../recipes/recipes.component';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  constructor(private recipe:DataService) { }

  ngOnInit(): void {
    
  }
  recipes(value:string)
  {
    this.recipe.search_string=value
    console.log(this.recipe.search_string)
  }

}
