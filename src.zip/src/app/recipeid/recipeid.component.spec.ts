import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecipeidComponent } from './recipeid.component';

describe('RecipeidComponent', () => {
  let component: RecipeidComponent;
  let fixture: ComponentFixture<RecipeidComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecipeidComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecipeidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
