import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipeid',
  templateUrl: './recipeid.component.html',
  styleUrls: ['./recipeid.component.css']
})
export class RecipeidComponent implements OnInit {
  @Input() recipe_data:any={}

  constructor() { }

  ngOnInit(): void {
  }

}
